import pytest

fastapi = pytest.importorskip("fastapi")
pytest.importorskip("starlette")

from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient

from pinelabs_p3p_server import (
    Amount,
    ChargeOptions,
    P3PEnvironment,
    PaymentGateway,
    PaymentMethod,
    PineLabsOnlineServerConfig,
)
from pinelabs_p3p_server.fastapi_mw import PaymentRequired


def test_payment_required_dependency_binds_request_and_response() -> None:
    app = FastAPI()
    config = PineLabsOnlineServerConfig(
        clientId="server-id",
        clientSecret="server-secret",
        paymentGateway=PaymentGateway.PineLabsOnline,
        availablePaymentMethods=[PaymentMethod.RESERVE_PAY],
        realm=P3PEnvironment.SANDBOX,
        env=P3PEnvironment.SANDBOX,
    )
    require_payment = PaymentRequired(
        config,
        ChargeOptions(amount=Amount(value=10000, currency="INR"), resource="/api/paid"),
    )

    @app.get("/api/paid", dependencies=[Depends(require_payment)])
    async def paid():
        return {"paid": True}

    response = TestClient(app).get("/api/paid")

    assert response.status_code == 402
    assert "WWW-Authenticate" in response.headers
