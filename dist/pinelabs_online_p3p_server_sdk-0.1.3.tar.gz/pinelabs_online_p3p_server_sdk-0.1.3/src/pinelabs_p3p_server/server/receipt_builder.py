from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

from ..types.capture import CaptureResult, ReceiptData, Settlement
from ..types.payment import PaymentGateway, PaymentMethod
from ..utils.base64url import encode_json

PAYMENT_RECEIPT_PREFIX = "Payment "


def build_receipt_data(
    capture_result: CaptureResult,
    challenge_id: str,
    payment_gateway: Optional[PaymentGateway] = None,
    payment_method: Optional[PaymentMethod] = None,
) -> ReceiptData:
    """Build structured receipt data from a successful capture result."""
    raw = capture_result.raw
    amount = raw.get("amount") or raw.get("payment_amount") or {}
    if isinstance(amount, dict):
        amount_value = int(amount.get("value", 0) or 0)
        currency = amount.get("currency", "INR")
    else:
        amount_value = int(amount or 0)
        currency = "INR"
    amount_major = f"{amount_value / 100:.2f}"
    timestamp = raw.get("settled_at") or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    resolved_gateway = payment_gateway or capture_result.payment_gateway
    resolved_method = payment_method or capture_result.payment_method
    capture_id = raw.get("merchant_payment_debit_reference") or raw.get("capture_id") or ""
    return ReceiptData(
        status="success",
        timestamp=timestamp,
        reference=capture_id,
        challengeId=challenge_id,
        settlement=Settlement(amount=amount_major, currency=currency) if amount_value else None,
        paymentGateway=resolved_gateway,
        paymentMethod=resolved_method,
        orderId=raw.get("order_id") or None,
        merchantOrderReference=raw.get("merchant_order_reference") or raw.get("merchant_payment_debit_reference") or None,
    )


def build_receipt_header(
    capture_result: CaptureResult,
    challenge_id: str,
    payment_gateway: Optional[PaymentGateway] = None,
    payment_method: Optional[PaymentMethod] = None,
) -> str:
    """Encode capture receipt data as `Payment <base64url>`."""
    receipt = build_receipt_data(capture_result, challenge_id, payment_gateway, payment_method)
    payload = {
        "status": receipt.status,
        "timestamp": receipt.timestamp,
        "reference": receipt.reference,
        "challengeId": receipt.challengeId,
        "orderId": receipt.orderId,
        "merchantOrderReference": receipt.merchantOrderReference,
        "settlement": {"amount": receipt.settlement.amount, "currency": receipt.settlement.currency},
    }
    if receipt.paymentGateway:
        payload["paymentGateway"] = _enum_value(receipt.paymentGateway)
    if receipt.paymentMethod:
        payload["paymentMethod"] = _enum_value(receipt.paymentMethod)
    return f"{PAYMENT_RECEIPT_PREFIX}{encode_json(payload)}"


def build_failure_receipt_data(
    challenge_id: str,
    error: str,
    payment_gateway: Optional[PaymentGateway] = None,
    payment_method: Optional[PaymentMethod] = None,
) -> ReceiptData:
    """Build a failure receipt object for adapters that need explicit failure data."""
    del error
    return ReceiptData(
        status="failure",
        timestamp=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        reference="",
        challengeId=challenge_id,
        settlement=Settlement(amount="0.00", currency="INR"),
        paymentGateway=payment_gateway,
        paymentMethod=payment_method,
    )


def _enum_value(value: Any) -> str:
    return value.value if hasattr(value, "value") else str(value)
