"""Seller SDK tests — covered transitively by the buyer SDK's e2e test."""
from dataclasses import asdict
from types import SimpleNamespace

from pinelabs_p3p_seller import (
    Amount,
    ChargeOptions,
    P3PEnvironment,
    P3PCaptureError,
    P3PError,
    PaymentGateway,
    PaymentMethod,
    PluralP3P,
    PluralSellerConfig,
    decide_payment,
)
from pinelabs_p3p_seller.server.credential_verifier import CredentialVerifier
from pinelabs_p3p_seller.utils.base64url import decode_json, encode_json


def _config() -> PluralSellerConfig:
    return PluralSellerConfig(
        clientId="seller-id",
        clientSecret="seller-secret",
        challengeSecretKey="shared-hmac-secret-please-change",
        paymentGateway=PaymentGateway.PineLabsOnline,
        availablePaymentMethods=[PaymentMethod.UpiSbmd, PaymentMethod.Crypto],
        realm=P3PEnvironment.SANDBOX,
        env=P3PEnvironment.SANDBOX,
    )


def test_challenge_generator_produces_stable_id() -> None:
    mpp = PluralP3P.create(_config())
    a = mpp.generate_challenge(
        ChargeOptions(amount=Amount(value=10000, currency="INR"), resource="/api/x")
    )
    assert a.challenge.id.startswith("ch_")
    assert a.challenge.realm == P3PEnvironment.SANDBOX
    assert a.challenge.paymentGateway == PaymentGateway.PineLabsOnline
    assert a.challenge.request.amount == "100.00"
    assert a.challenge.request.availablePaymentMethods == [PaymentMethod.UpiSbmd, PaymentMethod.Crypto]
    assert a.problemDetails.status == 402


def test_credential_verifier_rejects_missing_header() -> None:
    verifier = CredentialVerifier(_config())
    result = verifier.verify(None)
    assert result.valid is False
    assert "P3P-Credential" in (result.error or "")


def test_decide_payment_propagates_upstream_capture_failures(monkeypatch) -> None:
    def _fake_verify(self, authorization_header):
        del authorization_header
        return SimpleNamespace(
            valid=True,
            error=None,
            credential=SimpleNamespace(
                payload=SimpleNamespace(token="ppt_test", payment_method=PaymentMethod.UpiSbmd),
                challenge=SimpleNamespace(id="ch_test"),
            ),
        )

    def _fake_capture(self, options):
        del options
        raise P3PCaptureError(
            "Capture failed: Unknown error",
            P3PError(
                "INTERNAL_ERROR",
                "Unknown error",
                500,
                {"reason": "SOMETHING_WENT_WRONG"},
            ),
        )

    monkeypatch.setattr(
        "pinelabs_p3p_seller.server.middleware.generic.CredentialVerifier.verify",
        _fake_verify,
    )
    monkeypatch.setattr(
        "pinelabs_p3p_seller.server.middleware.generic.CaptureClient.capture",
        _fake_capture,
    )

    decision = decide_payment(
            credential_header="Payment dummy-credential",
        config=_config(),
        charge_options=ChargeOptions(
            amount=Amount(value=100, currency="INR"),
            resource="/rides/confirm",
        ),
    )

    assert decision.action == "error"
    assert decision.status == 502
    assert decision.problem_details == {
        "type": "urn:plural:error:payment-capture-failed",
        "title": "Payment Capture Failed",
        "status": 502,
        "detail": "Capture failed: Unknown error",
        "upstream": {
            "code": "INTERNAL_ERROR",
            "http_status": 500,
            "details": {"reason": "SOMETHING_WENT_WRONG"},
        },
    }


def test_decide_payment_receipt_includes_gateway_and_payment_method(monkeypatch) -> None:
    def _fake_verify(self, authorization_header):
        del authorization_header
        return SimpleNamespace(
            valid=True,
            error=None,
            credential=SimpleNamespace(
                payload=SimpleNamespace(
                        token="ppt_test",
                        payment_method=PaymentMethod.Crypto,
                        customer_reference="cust-ref-1",
                        mobile_number="9876543210",
                    ),
                challenge=SimpleNamespace(id="ch_test"),
            ),
        )

    def _fake_capture(self, options):
        assert options.challengeId == "ch_test"
        return SimpleNamespace(
            capture_id="cap_test",
            order_id="ord_test",
            merchant_order_reference=options.merchantOrderReference,
            amount=options.amount,
            settled_at="2030-01-01T00:00:00Z",
        )

    monkeypatch.setattr(
        "pinelabs_p3p_seller.server.middleware.generic.CredentialVerifier.verify",
        _fake_verify,
    )
    monkeypatch.setattr(
        "pinelabs_p3p_seller.server.middleware.generic.CaptureClient.capture",
        _fake_capture,
    )

    decision = decide_payment(
            credential_header="Payment dummy-credential",
        config=_config(),
        charge_options=ChargeOptions(
            amount=Amount(value=100, currency="INR"),
            resource="/rides/confirm",
        ),
    )

    receipt = decode_json(decision.receipt_header[len("Payment "):])
    assert "method" not in receipt
    assert receipt["paymentGateway"] == "PINE LABS ONLINE"
    assert receipt["paymentMethod"] == "CRYPTO"


def test_credential_verifier_rejects_payment_method_outside_signed_challenge() -> None:
    config = PluralSellerConfig(
        clientId="seller-id",
        clientSecret="seller-secret",
        challengeSecretKey="shared-hmac-secret-please-change",
        paymentGateway=PaymentGateway.PineLabsOnline,
        availablePaymentMethods=[PaymentMethod.UpiSbmd],
        realm=P3PEnvironment.SANDBOX,
        env=P3PEnvironment.SANDBOX,
    )
    seller = PluralP3P.create(config)
    challenge = seller.generate_challenge(
        ChargeOptions(amount=Amount(value=10000, currency="INR"), resource="/api/x")
    ).challenge

    credential = {
        "challenge": asdict(challenge),
        "source": "buyer-client",
        "payload": {
            "type": "token",
            "token": "MPP_TOK_test",
            "payment_method": "CRYPTO",
        },
    }
    result = seller.verify_credential(f"Payment {encode_json(credential)}")

    assert result.valid is False
    assert "Selected payment method CRYPTO is not accepted" in (result.error or "")
